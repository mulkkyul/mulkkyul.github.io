clear all; clc; close all;


%% Softmax Parameters
softmaxUnit = 10; % Number of Softmax Units per analog dimension
minVal = -3; maxVal = 3; %% Add a bit of marin here.
SIGMA = 0.5;



%% SOFTMAX TRANSFORM
traj = load('./data_analog.txt');
fid_s = fopen('./data_softmax.txt','w');
for idxStep = 1:size(traj,1)
    for idxJnt = 1:size(traj,2)
        references = linspace(minVal,maxVal,softmaxUnit);
        val = zeros(1,softmaxUnit);
        sumVal = 0;
        for idxRef = 1:softmaxUnit
            val(1,idxRef) = power((references(1,idxRef) - traj(idxStep,idxJnt)),2);
            val(1,idxRef) = exp(-val(1,idxRef) / SIGMA);
            sumVal = sumVal + val(1,idxRef);
        end
        for idxRef = 1:softmaxUnit
            val(1,idxRef) = val(1,idxRef) / sumVal;
            fprintf(fid_s,'%.6f\t',val(1,idxRef));
        end
    end
    fprintf(fid_s,'\n');
end
fclose(fid_s);

%% INVERSE TRANSFORM
softmax = load('./data_softmax.txt');
fid_i = fopen('./data_analog_inverse.txt','w');

analogJnt = 1;
analog = zeros(size(softmax,1),size(softmax,2)/softmaxUnit);
for idxJnt = 1:softmaxUnit:size(softmax,2)
    references = linspace(minVal,maxVal,softmaxUnit);
    analog(:,analogJnt) = softmax(:,idxJnt:idxJnt+softmaxUnit-1) * transpose(references);
    analogJnt = analogJnt + 1;
end

for idxStep = 1:size(softmax,1)
    for idxJnt = 1:size(analog,2)
        fprintf(fid_i,'%.6f\t',analog(idxStep,idxJnt));
    end
    fprintf(fid_i,'\n');
end
fclose(fid_i);


%% Comparison between original analog file & inverse transformed analog file
traj = load('./data_analog.txt');
inverse = load('./data_analog_inverse.txt');

cmap = jet(size(traj,2));
t = linspace(1,size(traj,1),size(traj,1));
subplot(1,3,[1 2])
for idxJnt = 1:size(traj,2)
    plot(t,traj(:,idxJnt),'color',cmap(idxJnt,:));
    hold on;
    plot(t,inverse(:,idxJnt),'--','color',cmap(idxJnt,:));
    hold on;
    ylim([minVal maxVal])
end
diff = immse(traj,inverse);
title(sprintf('MSE = %.5f',diff));

%% Just to check the softmax output
subplot(1,3,3)
softmax = load('./data_softmax.txt');
idxAnalog = 1;
for idxJnt = 1:softmaxUnit:size(softmax,2)
    vals = softmax(:,idxJnt:idxJnt+softmaxUnit-1);
    for idxStep = 1:size(vals,1)
        bar(vals(idxStep,:));
        title(sprintf('Dim: %d \t Step: %04d',idxAnalog, idxStep));
        ylim([0 1]);
        xlim([0 11]);
        pause(0.01);
    end
    idxAnalog = idxAnalog + 1;
end
